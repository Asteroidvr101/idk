#pragma once

#include "FortGameModeZone.h"

class AFortGameModePvPBase : public AFortGameModeZone
{
public:
};