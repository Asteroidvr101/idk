#pragma once

#include "UnrealString.h"

struct FStringAssetReference
{
	FString AssetLongPathname;
};