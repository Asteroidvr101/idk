#pragma once

#include "Controller.h"

class AAIController : public AController
{
public:
};